# 🧠 Assistente de Pesquisa Qualitativa com Arquitetura SOLID + MVC

Este projeto é um assistente inteligente que classifica trechos de entrevistas (quotes) em constructos teóricos, com base em definições fornecidas. Ele segue os princípios de design SOLID e o padrão MVC, garantindo modularidade, clareza e facilidade de manutenção.

---

## 📁 Estrutura do Projeto

```
qualitative_assistant/
├── app.py                         # Interface principal com Gradio
├── main_controller.py            # Controller central (MVC)
├── requirements.txt              # Dependências do projeto
├── requirements-dev.txt          # Dependências de desenvolvimento/testes
├── .env.example                  # Exemplo de configuração da API
├── core/
│   ├── construct_loader.py       # Model: Carrega constructos manualmente ou de planilha
│   ├── dataset_loader.py         # Model: Carrega planilha de quotes
│   └── pipeline.py               # Orquestra classificação
├── classifiers/
│   ├── base.py                   # Interface BaseQuoteClassifier
│   ├── embedding.py              # Classificador via embeddings
│   └── llm.py                    # Classificador via modelos LLM (GPT)
├── data/
│   ├── exemplo_constructos.xlsx  # Planilha de constructos exemplo
│   └── exemplo_quotes.xlsx       # Planilha de quotes exemplo
├── tests/
│   ├── test_construct_loader.py
│   ├── test_dataset_loader.py
│   └── test_embedding_classifier.py
```

---

## ▶️ Como Executar

1. Instale as dependências:
```bash
pip install -r requirements.txt
```

2. Configure a variável de ambiente com sua chave da OpenAI:

Crie um arquivo `.env` na raiz do projeto (ou copie de `.env.example`):

```
OPENAI_API_KEY=sk-sua-chave-aqui
```

3. Execute a aplicação:
```bash
python app.py
```

A interface Gradio será aberta no navegador.

---

## 🧪 Rodando os testes

1. Instale as dependências de desenvolvimento:
```bash
pip install -r requirements-dev.txt
```

2. Execute os testes com pytest:
```bash
pytest
```

---

## ✨ Tecnologias
- Python 3.11+
- Gradio
- LangChain + OpenAI
- SentenceTransformers
- Pandas
- Pytest

---

## 📌 Arquitetura

- **Model**: `core/`, `classifiers/`
- **View**: interface via Gradio (`app.py`)
- **Controller**: `main_controller.py`